// Ido Levy 318949294

/**
 * @author Ido Levy
 */
public class TripletOfZero {
    /**
     *
     * @param numbers A string describing how should the triplet be sorted (asc/desc), an array of integers
     * @return The array of integers
     */
    public static int[] stringsToArray(String[] numbers) {
        int[] arr = new int[numbers.length - 1];
        for (int i = 0; i < arr.length; ++i) {
            arr[i] = Integer.parseInt(numbers[i + 1]);
        }
        return arr;
    }

    /**
     *
     * @param numbers An array of integers
     * @return A subsequence of numbers such that: it's length is 3, and it's sum is 0 if it exists, else null
     */
    public static int[] tripletOfZero(int[] numbers) {
        for (int i = 0; i < numbers.length - 2; ++i) {
            for (int j = i + 1; j < numbers.length - 1; ++j) {
                for (int k = j + 1; k < numbers.length; ++k) {
                    if (numbers[i] + numbers[j] + numbers[k] == 0) {
                        return new int[]{numbers[i], numbers[j], numbers[k]};
                    }
                }
            }
        }
        return null;
    }

    /**
     *
     * @param arr An array of integers
     * @param i An integer in [0, arr.length - 1]
     * @param j An integer in [0, arr.length - 1]
     */
    public static void swap(int[] arr, int i, int j) {
        int tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
    }

    /**
     *
     * @param arr An array of integers
     */
    public static void bubbleSort(int[] arr) {
        for (int i = arr.length - 1; i > 0; --i) {
            for (int j = 0; j < i; ++j) {
                if (arr[j] > arr[j + 1]) {
                    swap(arr, j, j + 1);
                }
            }
        }
    }

    /**
     *
     * @param numbers A triplet of integers
     */
    public static void ascTripletPrint(int[] numbers) {
        System.out.print("[" + numbers[0] + ", " + numbers[1] + ", " + numbers[2] + "]");
    }

    /**
     *
     * @param numbers A triplet of integers
     */
    public static void descTripletPrint(int[] numbers) {
        System.out.print("[" + numbers[2] + ", " + numbers[1] + ", " + numbers[0] + "]");
    }

    /**
     *
     * @param order A string describing how should the triplet be sorted (asc/desc), an array of integers
     * @return true if the string equals "asc", else false
     */
    public static boolean isAsc(String[] order) {
        return order[0].equals("asc");
    }

    /**
     *
     * @param args A string describing how should the triplet be sorted (asc/desc), an array of integers
     */
    public static void main(String[] args) {
        int[] numbers = stringsToArray(args);
        int[] triplet = tripletOfZero(numbers);
        if (triplet == null) {
            System.out.print("the triplet is: -1");
        } else {
            bubbleSort(triplet);
            if (isAsc(args)) {
                ascTripletPrint(triplet);
            } else {
                descTripletPrint(triplet);
            }
        }
    }
}
