// Ido Levy 318949294

/**
 * @author Ido Levy
 */
public class PlaceInArray {
    /**
     * Prints n's index range in array (if n isn't in array then it's index range is [-1, -1]).
     * @param n An integer
     * @param array A sorted array of integers
     */
    public static void placeInArray(int n, int[] array) {
        int first = -1;
        int last = -1;
        for (int i = 0; i < array.length; ++i) {
            if (array[i] == n) {
                if (first == -1) {
                    first = i;
                }
                last = i;
            }
        }
        System.out.print(n + " start in " + first + " and end in " + last);
    }

    /**
     *
     * @param args A sorted array of integers, an integer
     * @return The sorted array of integers
     */
    public static int[] createArray(String[] args) {
        int[] array = new int[args.length - 1];
        for (int i = 0; i < args.length - 1; ++i) {
            array[i] = Integer.parseInt(args[i]);
        }
        return array;
    }

    /**
     *
     * @param args A sorted array of integers, an integer
     */
    public static void main(String[] args) {
        int[] array = createArray(args);
        int n = Integer.parseInt(args[args.length - 1]);
        placeInArray(n, array);
    }
}
