// Ido Levy 318949294

/**
 * @author Ido Levy
 */
public class ReverseNumber {
    /**
     *
     * @param n A positive integer
     * @return Reversed n
     */
    public static long reverseNumAux(long n) {
        long nRev = 0;
        while (n > 0) {
            nRev *= 10;
            nRev += n % 10;
            n /= 10;
        }
        return nRev;
    }
    /**
     *
     * @param n An integer
     * @return Reversed n if it's in [-2^31, 2^31 - 1], else 0
     */
    public static int reverseNum(int n) {
        long nRev;
        if (n < 0) {
            nRev = -reverseNumAux(-n);
        } else {
            nRev = reverseNumAux(n);
        }
        if (nRev < Integer.MIN_VALUE || nRev > Integer.MAX_VALUE) {
            return 0;
        }
        return (int) nRev;
    }
    /**
     *
     * @param args An integer in [-2^31, 2^31 - 1]
     */
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        System.out.print("reverse number: " + reverseNum(n));
    }
}
