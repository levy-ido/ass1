// Ido Levy 318949294

/**
 * @author Ido Levy
 */
public class Pow {
    /**
     *
     * @param n An integer representing the base
     * @param x An integer representing the exponent
     * @return n to the power of x
     */
    public static long powRecursive(long n, long x) {
        if (x == 0) {
            return 1;
        }
        return n * powRecursive(n, x - 1);
    }

    /**
     *
     * @param n An integer representing the base
     * @param x An integer representing the exponent
     * @return n to the power of x
     */
    public static long powIter(long n, long x) {
        int res = 1;
        while (x >= 1) {
            res *= n;
            --x;
        }
        return res;
    }

    /**
     *
     * @param args Two integers
     */
    public static void main(String[] args) {
        long n = Long.parseLong(args[0]);
        long x = Long.parseLong(args[1]);
        System.out.println("recursive: " + powRecursive(n, x));
        System.out.print("iterative: " + powIter(n, x));
    }
}
